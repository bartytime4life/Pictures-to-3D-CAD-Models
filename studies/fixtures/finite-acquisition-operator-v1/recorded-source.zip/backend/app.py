"""Same-origin local development API; no third-party reconstruction services."""

import asyncio
import json
import logging
import os
import re
import shutil
import sys
import time
import uuid
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Annotated

from fastapi import FastAPI, File, Form, HTTPException, Request, UploadFile
from fastapi.exceptions import RequestValidationError
from fastapi.responses import FileResponse, JSONResponse, RedirectResponse
from pydantic import BaseModel, ConfigDict

from .assistant import AssistantError, AssistantRequest, assistant_status, chat
from .models import BuildRequest, Detail, Reference
from .printing import load_printer_catalog
from .slicers import PROGRAMS, SlicerError, launch, launch_request_allowed, program_status
from .tracing import MAX_BYTES, TraceError, trace_image

ROOT = Path(__file__).resolve().parent.parent
LIBRARY_ROOT = ROOT / "reference-library"
JOB_ROOT = Path(os.environ.get("PICTURES_CAD_JOB_DIR", ROOT / ".local" / "jobs")).resolve()
SLICER_HANDOFF_ROOT = Path(
    os.environ.get("PICAD_SLICER_HANDOFF_DIR", ROOT / ".local" / "slicer-handoffs")
).resolve()
TTL_SECONDS = 3600
# Request bodies other than a photo upload (project recipes, assistant questions).
MAX_BODY = 10 * 1024 * 1024
CLEANUP_INTERVAL = 60
MAX_JOBS = 20
BUILD_TIMEOUT = 60
# Files only this app writes into a job directory: the build request, then the worker's
# result or failure. Expiry never removes a directory without one, so a shared
# PICTURES_CAD_JOB_DIR keeps other programs' similarly named directories.
JOB_MARKERS = ("input.json", "result.json", "error.json")
DOWNLOADS = {
    "step": ("model.step", "application/step"),
    "stl": ("model.stl", "model/stl"),
    "dxf": ("profile.dxf", "application/dxf"),
    "svg": ("profile.svg", "image/svg+xml"),
    "pdf": ("drawing.pdf", "application/pdf"),
    "scad": ("model.scad", "application/x-openscad"),
    "3mf": ("model.3mf", "model/3mf"),
    "bambu": ("bambu-handoff.zip", "application/zip"),
    "prusa": ("prusa-handoff.zip", "application/zip"),
    "project": ("project.json", "application/json"),
    "parts": ("parts.zip", "application/zip"),
}
UUID_PATTERN = re.compile(r"^[0-9a-f]{32}$")
# Mirror the companion's scripts/lib/serve.mjs publication boundary. Local CAD
# builds, environments, browser databases, logs and scratch reports are private.
LIBRARY_FILES = {
    "index.html",
    "HANDBOOK.md",
    "REFERENCES.md",
    "OPENSCAD.md",
    "sources.csv",
    "cadkit/README.md",
    "examples/build_plate.py",
    "examples/calculate.py",
    "examples/calculation-results.json",
    "examples/clearance-coupon.scad",
    "examples/plate-parameters.csv",
    "examples/two-hole-plate.scad",
    "examples/two-hole-plate.svg",
    "output/pdf/pictures-to-printable-cad.pdf",
}
LIBRARY_PATTERNS = (
    re.compile(r"assets/figures/[a-z0-9-]+\.svg"),
    re.compile(r"templates/[A-Za-z0-9-]+\.(?:md|csv)"),
    re.compile(
        r"examples/openscad-starter/(?:plate|coupon)/"
        r"(?:source\.scad|parameters\.csv|model\.stl|validation-results\.csv|"
        r"build\.json|preview\.png|render\.log|preview\.log)"
    ),
)
logger = logging.getLogger(__name__)


def cleanup_jobs():
    JOB_ROOT.mkdir(parents=True, exist_ok=True)
    now = time.time()
    for path in JOB_ROOT.iterdir():
        try:
            expired = (
                UUID_PATTERN.fullmatch(path.name)
                and path.is_dir()
                and now - path.stat().st_mtime >= TTL_SECONDS
                and any((path / marker).is_file() for marker in JOB_MARKERS)
            )
        except OSError:  # Removed or made unreadable meanwhile; check again next time.
            continue
        if expired:
            shutil.rmtree(path, ignore_errors=True)


@asynccontextmanager
async def lifespan(app):
    cleanup_jobs()
    app.state.cad_lock = asyncio.Lock()
    app.state.trace_lock = asyncio.Lock()
    app.state.assistant_lock = asyncio.Lock()
    app.state.slicer_lock = asyncio.Lock()
    app.state.slicer_last_launch = 0.0

    async def expire_jobs():
        while True:
            await asyncio.sleep(CLEANUP_INTERVAL)
            try:
                cleanup_jobs()
            except Exception:  # One failed pass must not end expiry for the service's lifetime.
                logger.exception("Temporary model cleanup failed; it will be retried.")

    reaper = asyncio.create_task(expire_jobs())
    try:
        yield
    finally:
        reaper.cancel()
        try:
            await reaper
        except asyncio.CancelledError:
            pass


app = FastAPI(title="Pictures to CAD", version="0.1.0", lifespan=lifespan)


class BodyTooLarge(HTTPException):
    def __init__(self, detail):
        super().__init__(413, detail)


def body_limit(path):
    """(bytes allowed, refusal) for a request body. A photo upload may be larger than
    any other request; both allow 64 KiB for multipart framing and form fields."""
    if path == "/api/trace":
        return MAX_BYTES + 64 * 1024, "Upload exceeds the 32 MiB limit."
    return MAX_BODY + 64 * 1024, "Upload exceeds the 10 MiB limit."


class BodyLimitMiddleware:
    """Bound multipart parsing as well as the decoded upload checked in tracing."""

    def __init__(self, app):
        self.app = app

    async def __call__(self, scope, receive, send):
        if scope["type"] != "http":
            return await self.app(scope, receive, send)
        limit, refusal = body_limit(scope.get("path", ""))
        headers = dict(scope.get("headers", []))
        length = headers.get(b"content-length")
        if length:
            try:
                too_large = int(length) > limit or int(length) < 0
            except ValueError:
                too_large = True
            if too_large:
                return await JSONResponse({"detail": refusal}, 413)(scope, receive, send)
        count = 0

        async def bounded_receive():
            nonlocal count
            message = await receive()
            count += len(message.get("body", b""))
            if count > limit:
                raise BodyTooLarge(refusal)
            return message

        try:
            await self.app(scope, bounded_receive, send)
        except BodyTooLarge:
            await JSONResponse({"detail": refusal}, 413)(scope, receive, send)


app.add_middleware(BodyLimitMiddleware)


@app.exception_handler(RequestValidationError)
async def invalid_input(request, exc):
    messages = []
    for error in exc.errors()[:3]:
        field = ".".join(str(v) for v in error["loc"] if v != "body")
        messages.append(f"{field}: {error['msg']}")
    return JSONResponse({"detail": "; ".join(messages)}, status_code=422)


@app.get("/api/health")
async def health():
    return {"status": "ok", "version": "0.1.0", "workflow": "measured-profile-extrusion"}


@app.get("/api/printers")
async def printers():
    return load_printer_catalog()


@app.get("/api/assistant/status")
async def local_assistant_status():
    return await asyncio.to_thread(assistant_status)


@app.post("/api/assistant/chat")
async def local_assistant_chat(request: AssistantRequest):
    lock = app.state.assistant_lock
    if lock.locked():
        raise HTTPException(429, "The local assistant is answering. Wait a moment and try again.")
    async with lock:
        # Cancelling an HTTP request cannot stop a worker thread. Keep its slot
        # until the bounded local request finishes, so repeated cancellation
        # cannot accumulate inference jobs on the Ollama server.
        worker = asyncio.create_task(asyncio.to_thread(chat, request))
        try:
            return await asyncio.shield(worker)
        except asyncio.CancelledError:
            while not worker.done():
                try:
                    await asyncio.shield(worker)
                except asyncio.CancelledError:
                    continue
                except AssistantError:
                    break
            if not worker.cancelled():
                worker.exception()
            raise
        except AssistantError as exc:
            raise HTTPException(exc.status_code, exc.detail) from exc


@app.post("/api/trace")
async def trace(
    file: Annotated[UploadFile, File()],
    threshold: Annotated[int, Form()] = -1,
    inverted: Annotated[bool, Form()] = False,
    detail: Annotated[Detail, Form()] = "standard",
    reference: Annotated[Reference, Form()] = "none",
    sheet_width_mm: Annotated[float | None, Form(gt=0, le=2000, allow_inf_nan=False)] = None,
    sheet_height_mm: Annotated[float | None, Form(gt=0, le=2000, allow_inf_nan=False)] = None,
    thickness_mm: Annotated[float | None, Form(gt=0, le=500, allow_inf_nan=False)] = None,
    snap: Annotated[bool, Form()] = True,
    fallback: Annotated[bool, Form()] = False,
):
    if reference == "custom" and (sheet_width_mm is None or sheet_height_mm is None):
        await file.close()
        raise HTTPException(422, "Enter the custom sheet's measured width and height.")
    sheet_mm = (sheet_width_mm, sheet_height_mm) if reference == "custom" else None
    lock = app.state.trace_lock
    if lock.locked():
        await file.close()
        raise HTTPException(
            429,
            "Another photo is being traced. Wait a moment and try again.",
            headers={"Retry-After": "3"},
        )
    async with lock:
        try:
            data = await file.read(MAX_BYTES + 1)
        finally:
            await file.close()
        if len(data) > MAX_BYTES:
            raise HTTPException(413, "Choose an image under 32 MiB.")
        # A cancelled request cannot terminate a native decode thread. Keep its
        # concurrency slot until the actual operation finishes, including repeated
        # cancellation; otherwise reconnecting clients could start unbounded work.
        worker = asyncio.create_task(
            asyncio.to_thread(
                trace_image,
                data,
                threshold,
                inverted,
                detail,
                reference,
                sheet_mm,
                thickness_mm,
                snap,
                fallback,
            )
        )
        try:
            return await asyncio.shield(worker)
        except asyncio.CancelledError:
            while not worker.done():
                try:
                    await asyncio.shield(worker)
                except asyncio.CancelledError:
                    continue
                except TraceError:
                    break
            if not worker.cancelled():
                worker.exception()  # Consume a completed error before preserving cancellation.
            raise
        except TraceError as exc:
            raise HTTPException(422, str(exc)) from exc


@app.post("/api/build")
async def build(request: BuildRequest):
    lock = app.state.cad_lock
    if lock.locked():
        raise HTTPException(
            429,
            "Another model is being built. Wait a moment and try again.",
            headers={"Retry-After": "3"},
        )
    async with lock:
        cleanup_jobs()
        jobs = [p for p in JOB_ROOT.iterdir() if UUID_PATTERN.fullmatch(p.name) and p.is_dir()]
        if len(jobs) >= MAX_JOBS:
            # Capacity is bounded; prior downloads stay valid until their TTL instead of disappearing silently.
            raise HTTPException(
                429,
                "Temporary model storage is full. Delete older models or wait for expiry, then try again.",
                headers={"Retry-After": "60"},
            )
        job_id = uuid.uuid4().hex
        job_dir = JOB_ROOT / job_id
        job_dir.mkdir(mode=0o700)
        process = None
        try:
            # Explicit UTF-8: names may be non-ASCII and the locale default may not be UTF-8.
            (job_dir / "input.json").write_text(request.model_dump_json(), encoding="utf-8")
            process = await asyncio.create_subprocess_exec(
                sys.executable,
                "-m",
                "backend.worker",
                str(job_dir),
                cwd=ROOT,
                stdout=asyncio.subprocess.DEVNULL,
                stderr=asyncio.subprocess.DEVNULL,
            )
            try:
                await asyncio.wait_for(process.wait(), timeout=BUILD_TIMEOUT)
            except TimeoutError as exc:
                process.kill()
                await process.wait()
                raise HTTPException(
                    504, "CAD generation exceeded 60 seconds. Reduce outline detail and try again."
                ) from exc
            if process.returncode != 0 or not (job_dir / "result.json").is_file():
                failure = job_dir / "error.json"
                if failure.is_file():
                    info = json.loads(failure.read_text(encoding="utf-8"))
                    if info.get("public") is True and isinstance(info.get("error"), str):
                        raise HTTPException(422, info["error"][:500])
                raise HTTPException(
                    422,
                    "This outline could not be converted to a solid. Reduce detail or remove very narrow features and try again.",
                )
            result = json.loads((job_dir / "result.json").read_text(encoding="utf-8"))
            (job_dir / "input.json").unlink(missing_ok=True)
            return result
        except BaseException:
            if process is not None and process.returncode is None:
                process.kill()
                await process.wait()
            shutil.rmtree(job_dir, ignore_errors=True)
            raise


def resolve_job(job_id: str):
    if not UUID_PATTERN.fullmatch(job_id):
        raise HTTPException(404, "Model not found. Rebuild it to create new exports.")
    directory = JOB_ROOT / job_id
    if not directory.is_dir() or not (directory / "result.json").is_file():
        raise HTTPException(404, "Model not found. Rebuild it to create new exports.")
    if time.time() - directory.stat().st_mtime >= TTL_SECONDS:
        shutil.rmtree(directory, ignore_errors=True)
        raise HTTPException(410, "This model has expired. Rebuild it to create fresh exports.")
    return directory


class SlicerLaunchRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")


@app.get("/api/slicers")
async def slicer_status():
    # Discovery only inspects configured paths; reading this endpoint never starts a program.
    return JSONResponse(program_status(), headers={"Cache-Control": "no-store"})


@app.post("/api/models/{job_id}/slicer/{program_id}", status_code=202)
async def open_in_slicer(
    job_id: str, program_id: str, request: Request, payload: SlicerLaunchRequest
):
    if not launch_request_allowed(
        request.client.host if request.client else None,
        str(request.url),
        request.headers.get("origin"),
        request.headers.get("content-type", ""),
    ):
        raise HTTPException(403, "Open a slicer from the workbench on this computer.")
    if program_id not in PROGRAMS:
        raise HTTPException(404, "Slicer not found.")
    directory = resolve_job(job_id)
    async with app.state.slicer_lock:
        if time.monotonic() - app.state.slicer_last_launch < 2:
            raise HTTPException(429, "Wait a moment before opening another slicer window.")
        app.state.slicer_last_launch = time.monotonic()
        task = asyncio.create_task(
            asyncio.to_thread(launch, program_id, directory / "model.3mf", SLICER_HANDOFF_ROOT)
        )
        try:
            result = await asyncio.shield(task)
        except asyncio.CancelledError:
            # The native thread still runs after a disconnected/cancelled caller.
            # Retain the lock until its side effect finishes before accepting another launch.
            while not task.done():
                try:
                    await asyncio.shield(task)
                except asyncio.CancelledError:
                    continue
                except (SlicerError, OSError):
                    break
            if not task.cancelled():
                task.exception()
            raise
        except SlicerError as exc:
            raise HTTPException(409, str(exc)) from None
    return result


@app.get("/api/download/{job_id}/{kind}")
async def download(job_id: str, kind: str):
    if kind not in DOWNLOADS:
        raise HTTPException(404, "Export format not found.")
    directory = resolve_job(job_id)
    name, media_type = DOWNLOADS[kind]
    if not (directory / name).is_file():
        raise HTTPException(404, "This export is not available for this model.")
    return FileResponse(
        directory / name,
        media_type=media_type,
        filename=name,
        headers={"Cache-Control": "private, no-store", "X-Content-Type-Options": "nosniff"},
    )


@app.delete("/api/models/{job_id}", status_code=204)
async def delete_model(job_id: str):
    directory = resolve_job(job_id)
    shutil.rmtree(directory)


@app.delete("/api/models")
async def clear_models():
    lock = app.state.cad_lock
    if lock.locked():
        raise HTTPException(
            409, "A model is being built. Wait for it to finish before clearing exports."
        )
    async with lock:
        deleted = 0
        for directory in JOB_ROOT.iterdir():
            if (
                UUID_PATTERN.fullmatch(directory.name)
                and directory.is_dir()
                and (directory / "result.json").is_file()
            ):
                shutil.rmtree(directory)
                deleted += 1
        return {"deleted": deleted}


@app.get("/reference-library")
async def library_home():
    return RedirectResponse("/reference-library/index.html")


@app.get("/reference-library/{path:path}")
async def library_file(path: str):
    path = path or "index.html"
    if path not in LIBRARY_FILES and not any(
        pattern.fullmatch(path) for pattern in LIBRARY_PATTERNS
    ):
        raise HTTPException(404, "Library file not found.")
    try:
        root = LIBRARY_ROOT.resolve()
        target = (root / path).resolve()
        if not target.is_relative_to(root) or not target.is_file():
            raise HTTPException(404, "Library file not found.")
    except (OSError, ValueError):
        raise HTTPException(404, "Library file not found.") from None
    return FileResponse(
        target,
        headers={"Cache-Control": "no-cache", "X-Content-Type-Options": "nosniff"},
    )


@app.get("/{path:path}")
async def frontend(path: str):
    if path == "api" or path.startswith("api/"):
        raise HTTPException(404, "API route not found.")
    dist = (ROOT / "frontend" / "dist").resolve()
    try:
        target = (dist / path).resolve()
        if not target.is_relative_to(dist):
            raise HTTPException(404, "File not found.")
        found = target.is_file()
    except (OSError, ValueError):  # A null byte or overlong name cannot name a file here.
        raise HTTPException(404, "File not found.") from None
    if found:
        return FileResponse(target)
    if path:
        raise HTTPException(404, "File not found.")
    if (dist / "index.html").is_file():
        return FileResponse(dist / "index.html", headers={"Cache-Control": "no-cache"})
    raise HTTPException(
        404, "Frontend not built. Run npm run build, or use the Vite development server."
    )
